const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Sample data structure for Beyblades
let beyblades = [
  { name: 'Dragoon', attackPower: 80, defensePower: 60, specialMove: 'Starblast Attack' },
  { name: 'Dranzer', attackPower: 75, defensePower: 65, specialMove: 'Blazing Gig Tempest' },
];

// GET /beyblades - Return a list of all available Beyblades
app.get('/beyblades', (req, res) => {
  res.json(beyblades);
});

// GET /beyblades/:name - Return details of a specific Beyblade by name
app.get('/beyblades/:name', (req, res) => {
  const { name } = req.params;
  const beyblade = beyblades.find(b => b.name.toLowerCase() === name.toLowerCase());

  if (beyblade) {
    res.json(beyblade);
  } else {
    res.status(404).json({ message: 'Beyblade not found' });
  }
});

// POST /battle - Simulate a battle between two Beyblades
app.post('/battle', (req, res) => {
  const { beyblade1, beyblade2 } = req.body;

  console.log('Request body:', req.body); // Debugging request body

  // Check if beyblade1 and beyblade2 are provided
  if (!beyblade1 || !beyblade2) {
    return res.status(400).json({ message: 'Both beyblade1 and beyblade2 are required' });
  }

  // Find both Beyblades by their names
  const blade1 = beyblades.find(b => b.name.toLowerCase() === beyblade1.toLowerCase());
  const blade2 = beyblades.find(b => b.name.toLowerCase() === beyblade2.toLowerCase());

  console.log('Beyblade 1:', blade1); // Debugging the found beyblade1
  console.log('Beyblade 2:', blade2); // Debugging the found beyblade2

  // Check if both Beyblades exist
  if (!blade1 || !blade2) {
    return res.status(404).json({ message: 'One or both Beyblades not found' });
  }

  // Battle simulation logic (simple comparison of attack and defense stats)
  let winner;
  const blade1Power = blade1.attackPower - blade2.defensePower;
  const blade2Power = blade2.attackPower - blade1.defensePower;

  if (blade1Power > blade2Power) {
    winner = blade1;
  } else if (blade2Power > blade1Power) {
    winner = blade2;
  } else {
    winner = null; // It's a tie
  }

  const result = {
    beyblade1: blade1.name,
    beyblade2: blade2.name,
    winner: winner ? winner.name : 'It\'s a tie!',
    battleDetails: {
      blade1Attack: blade1.attackPower,
      blade2Attack: blade2.attackPower,
      blade1Defense: blade1.defensePower,
      blade2Defense: blade2.defensePower,
      blade1SpecialMove: blade1.specialMove,
      blade2SpecialMove: blade2.specialMove,
    }
  };

  res.json(result);
});



// PUT /beyblades/:name/upgrade - Upgrade a Beyblade's stats (attack or defense)
app.put('/beyblades/:name/upgrade', (req, res) => {
  const { name } = req.params;
  const { attackIncrease, defenseIncrease } = req.body;

  let beyblade = beyblades.find(b => b.name.toLowerCase() === name.toLowerCase());

  if (!beyblade) {
    return res.status(404).json({ message: 'Beyblade not found' });
  }

  // Upgrade the stats if provided
  if (attackIncrease) {
    beyblade.attackPower += attackIncrease;
  }
  if (defenseIncrease) {
    beyblade.defensePower += defenseIncrease;
  }

  res.json({ message: 'Beyblade upgraded successfully', beyblade });
});

app.listen(port, () => {
  console.log(`Beyblade Battle Arena API listening at http://localhost:${port}`);
});
