const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Sample data structures
let rangers = [
  { name: 'Jason', color: 'Red', specialAbility: 'Leadership', powerLevel: 90 },
  { name: 'Trini', color: 'Yellow', specialAbility: 'Agility', powerLevel: 85 },
  { name: 'Zack', color: 'Black', specialAbility: 'Strength', powerLevel: 88 },
  { name: 'Kimberly', color: 'Pink', specialAbility: 'Archery', powerLevel: 83 },
  { name: 'Billy', color: 'Blue', specialAbility: 'Tech Savvy', powerLevel: 80 }
];

let teams = [];

// GET /rangers - Return list of all available Rangers
app.get('/rangers', (req, res) => {
  res.json(rangers);
});

// POST /teams - Create a new Power Rangers team
app.post('/teams', (req, res) => {
  const { teamName, members } = req.body;

  // Validate request
  if (!teamName || !members || !Array.isArray(members) || members.length === 0) {
    return res.status(400).json({ message: 'Team name and a list of Rangers are required' });
  }

  // Check if the team name already exists
  const existingTeam = teams.find(team => team.teamName.toLowerCase() === teamName.toLowerCase());
  if (existingTeam) {
    return res.status(400).json({ message: 'Team name already exists' });
  }

  // Validate that all selected Rangers exist and are not in a team
  let teamMembers = [];
  for (let memberName of members) {
    const ranger = rangers.find(r => r.name.toLowerCase() === memberName.toLowerCase());

    if (!ranger) {
      return res.status(404).json({ message: `Ranger ${memberName} does not exist` });
    }

    // Check if Ranger is already in a team
    const inTeam = teams.some(team => team.members.some(m => m.name === ranger.name));
    if (inTeam) {
      return res.status(400).json({ message: `Ranger ${ranger.name} is already in a team` });
    }

    teamMembers.push(ranger);
  }

  // Calculate combined team power level
  const combinedPowerLevel = teamMembers.reduce((total, member) => total + member.powerLevel, 0);

  // Create and add the team
  const newTeam = { teamName, members: teamMembers, combinedPowerLevel };
  teams.push(newTeam);

  res.status(201).json(newTeam);
});

// GET /teams/:teamName - Retrieve team details by team name
app.get('/teams/:teamName', (req, res) => {
  const { teamName } = req.params;
  const team = teams.find(t => t.teamName.toLowerCase() === teamName.toLowerCase());

  if (team) {
    res.json(team);
  } else {
    res.status(404).json({ message: 'Team not found' });
  }
});

// DELETE /teams/:teamName - Disband a team
app.delete('/teams/:teamName', (req, res) => {
  const { teamName } = req.params;
  const teamIndex = teams.findIndex(t => t.teamName.toLowerCase() === teamName.toLowerCase());

  if (teamIndex !== -1) {
    teams.splice(teamIndex, 1);
    res.json({ message: `Team ${teamName} has been disbanded` });
  } else {
    res.status(404).json({ message: 'Team not found' });
  }
});

app.listen(port, () => {
  console.log(`Power Rangers Team Assemble API listening at http://localhost:${port}`);
});
