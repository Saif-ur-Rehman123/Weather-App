const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Sample data structures
let stationInfo = {
  name: 'Starbase Alpha',
  capacity: 1000,
  currentPopulation: 500,
};

let inhabitants = [
  { name: 'Zorgax', species: 'Zorgonian', purposeOfStay: 'Diplomatic mission' },
];

let resources = [
  { name: 'Oxygen', quantity: 10000, maxCapacity: 20000, criticalityLevel: 'High' },
];

let researchProjects = [
  { name: 'Project Nebula', status: 'Ongoing', leadResearcher: 'Dr. Quasar', priority: 'High' },
];

// GET /station-info
app.get('/station-info', (req, res) => {
  res.json(stationInfo);
});

// GET /inhabitants
app.get('/inhabitants', (req, res) => {
  res.json(inhabitants);
});

// PUT /station-info
app.put('/station-info', (req, res) => {
  const { name, capacity, currentPopulation } = req.body;

  // Check if new capacity is less than current population
  if (capacity < stationInfo.currentPopulation) {
    return res.status(400).json({ message: 'New capacity cannot be less than current population.' });
  }

  // Update the station info
  stationInfo = {
    ...stationInfo,
    name: name || stationInfo.name,
    capacity: capacity || stationInfo.capacity,
    currentPopulation: currentPopulation || stationInfo.currentPopulation,
  };

  res.json({ message: 'Station info updated successfully', stationInfo });
});

// PUT /inhabitants/:name
app.put('/inhabitants/:name', (req, res) => {
  const { name } = req.params;
  const { purposeOfStay } = req.body;

  const inhabitant = inhabitants.find(i => i.name === name);

  if (!inhabitant) {
    return res.status(404).json({ message: 'Inhabitant not found' });
  }

  // Update the inhabitant's purpose of stay
  inhabitant.purposeOfStay = purposeOfStay || inhabitant.purposeOfStay;

  res.json({ message: 'Inhabitant updated successfully', inhabitant });
});

// PUT /resources/:resourceName
app.put('/resources/:resourceName', (req, res) => {
  const { resourceName } = req.params;
  const { quantity, maxCapacity, criticalityLevel } = req.body;

  const resource = resources.find(r => r.name === resourceName);

  if (!resource) {
    return res.status(404).json({ message: 'Resource not found' });
  }

  // Update resource properties
  if (quantity !== undefined) resource.quantity = quantity;
  if (maxCapacity !== undefined) resource.maxCapacity = maxCapacity;
  if (criticalityLevel) resource.criticalityLevel = criticalityLevel;

  res.json({ message: 'Resource updated successfully', resource });
});

// PUT /research-projects/:projectName
app.put('/research-projects/:projectName', (req, res) => {
  const { projectName } = req.params;
  const { status, leadResearcher, allocatedResources, priority } = req.body;

  const project = researchProjects.find(p => p.name === projectName);

  if (!project) {
    return res.status(404).json({ message: 'Research project not found' });
  }

  // Update project properties
  project.status = status || project.status;
  project.leadResearcher = leadResearcher || project.leadResearcher;
  project.priority = priority || project.priority;

  res.json({ message: 'Research project updated successfully', project });
});
// Sample data structures for security protocols and maintenance schedule

let securityProtocols = {
  accessLevels: {
    'low': ['visitor areas'],
    'medium': ['lab areas'],
    'high': ['control room', 'research labs']
  },
  restrictedAreas: ['control room', 'research labs'],
  emergencyProcedures: ['lockdown', 'evacuation'],
};

let maintenanceSchedule = [
  { task: 'Air filter replacement', crew: 'Crew A', priority: 'High', scheduledDate: '2024-10-20' },
  { task: 'Power generator inspection', crew: 'Crew B', priority: 'Medium', scheduledDate: '2024-11-01' },
];

// PUT /security-protocols
app.put('/security-protocols', (req, res) => {
  const { accessLevels, restrictedAreas, emergencyProcedures } = req.body;

  // Update access levels
  if (accessLevels) {
    securityProtocols.accessLevels = {
      ...securityProtocols.accessLevels,
      ...accessLevels,
    };
  }

  // Update restricted areas
  if (restrictedAreas) {
    securityProtocols.restrictedAreas = restrictedAreas;
  }

  // Update emergency procedures
  if (emergencyProcedures) {
    securityProtocols.emergencyProcedures = emergencyProcedures;
  }

  res.json({ message: 'Security protocols updated successfully', securityProtocols });
});

// PUT /maintenance-schedule
app.put('/maintenance-schedule', (req, res) => {
  const { task, crew, priority, scheduledDate } = req.body;

  // Find the maintenance task by name
  const maintenanceTask = maintenanceSchedule.find(m => m.task === task);

  if (!maintenanceTask) {
    return res.status(404).json({ message: 'Maintenance task not found' });
  }

  // Update the task details
  maintenanceTask.crew = crew || maintenanceTask.crew;
  maintenanceTask.priority = priority || maintenanceTask.priority;
  maintenanceTask.scheduledDate = scheduledDate || maintenanceTask.scheduledDate;

  res.json({ message: 'Maintenance schedule updated successfully', maintenanceSchedule });
});


app.listen(port, () => {
  console.log(`Galactic Space Station Management API listening at http://localhost:${port}`);
});
